package hus.oop.vector;

public class TestVector {
  public static void main(String[] args) {
    /*
     * TODO
     * 
     * Thực hiện các yêu cầu sau.
     * 
     * I. Test chức năng vector
     * - Sinh ngẫu nhiên một số tự nhiên, lưu giá trị sinh ra vào biến n.
     * - Tạo ra các vector có kích thước n, với các phần tử được sinh ngẫu nhiên.
     * Trong đó có 2 vector kiểu MyArrayList
     * và 2 vector có kiểu MyListVector.
     * - Viết các hàm để test các chứ năng của các vector, như thêm vào phần tử, xóa
     * bớt phần tử, sửa giá trị các
     * phần tử, cộng các vector, nhân vector với vô hướng, tích vô hướng 2 vector,
     * chuẩn vector, ... Mỗi lần thay
     * đổi vector hoặc tính toán, in kết quả ra terminal.
     * 
     * II. Lưu các kết quả chạy chương trình vào file text có tên
     * <Ten_MaSinhVien_Vector>.txt
     * (ví dụ NguyenVanA_123456_Vector.txt). Nén các file source code và file kết
     * quả vào file zip có tên
     * <Ten_MaSinhVien_Vector>.zip (ví dụ NguyenVanA_123456_Vector.zip), nộp lên
     * classroom.
     */
    int n = (int) (Math.random() * 10 + 1);
    int[] indices = { 1, 3, 4 };
    // MyListVector listVector1 = new MyListVector();
    // MyListVector listVector2 = new MyListVector();

    // // insert
    // for (int i = 0; i < n; i++) {
    // listVector1.insert((Math.random() * 10));
    // listVector2.insert(Math.random() * 10);
    // }

    // // size
    // System.out.println("Kích thức vector");
    // System.out.println("vector 1: " + listVector1.size());
    // System.out.println("vector 2: " + listVector2.size());

    // // set
    // System.out.println(listVector1);
    // System.out.println("Set vector 1 có giá trị 5.0 vào vị trị 1: ");
    // listVector1.set(5.0, 1);
    // System.out.println(listVector1);

    // System.out.println(listVector2);
    // System.out.println("Set vector 2 có giá trị 5.0 vào vị trị 1: ");
    // listVector2.set(5.0, 1);
    // System.out.println(listVector2);

    // // remove
    // System.out.println("Xóa phần tử ở vị trí index = 3: " +
    // listVector1.remove(3));
    // System.out.println("Xóa phần tử ở vị trí index = 3: " +
    // listVector2.remove(3));

    // // add
    // System.out.println("Cộng các phần tử của vector với value: " +
    // listVector1.add(3));
    // System.out.println("Vector hiện tại 1 " + listVector1);
    // System.out.println("Cộng vector hiện tại với một vector khác: " +
    // listVector1.add(listVector2));
    // System.out.println("Vector hiện tại 1 " + listVector1);
    // // minus
    // System.out.println("Trừ các phần tử của vector với value: " +
    // listVector2.minus(3));
    // System.out.println("Vector hiện tại 2 " + listVector2);
    // System.out.println("Trừ vector hiện tại với một vector khác: " +
    // listVector2.minus(listVector2));
    // System.out.println("Vector hiện tại 2 " + listVector2);

    // // Tích vô hướng
    // System.out.println("Tích vô hướng của hai vector: " +
    // listVector1.dot(listVector2));

    // // Các phần tử vector được lấy mũ power.
    // System.out.println("Các phần tử vector được lấy mũ power = 3: " +
    // listVector1.pow(3));

    // // Trích xuất tập con
    // System.out.println("Trích xuất tập con: " + listVector1.extract(indices));

    // ArrayList
    MyArrayVector arrayVector1 = new MyArrayVector();
    MyArrayVector arrayVector2 = new MyArrayVector();

    // insert
    for (int i = 0; i < n; i++) {
      arrayVector1.insert((Math.random() * 10));
      arrayVector2.insert(Math.random() * 10);
    }

    // size
    System.out.println("Kích thức vector");
    System.out.println("vector 1: " + arrayVector1.size());
    System.out.println("vector 2: " + arrayVector2.size());

    // set
    System.out.println(arrayVector1);
    System.out.println("Set vector 1 có giá trị 5.0 vào vị trị 1: ");
    arrayVector1.set(5.0, 1);
    System.out.println(arrayVector1);

    System.out.println(arrayVector2);
    System.out.println("Set vector 2 có giá trị 5.0 vào vị trị 1: ");
    arrayVector2.set(5.0, 1);
    System.out.println(arrayVector2);

    // remove
    System.out.println("Xóa phần tử ở vị trí index = 3: " + arrayVector1.remove(3));
    System.out.println("Xóa phần tử ở vị trí index = 3: " + arrayVector2.remove(3));

    // add
    System.out.println("Cộng các phần tử của vector với value: " + arrayVector1.add(3));
    System.out.println("Vector hiện tại 1 " + arrayVector1);
    System.out.println("Cộng vector hiện tại với một vector khác: " + arrayVector1.add(arrayVector2));
    System.out.println("Vector hiện tại 1 " + arrayVector1);

    // minus
    System.out.println("Trừ các phần tử của vector với value: " + arrayVector2.minus(3));
    System.out.println("Vector hiện tại 2 " + arrayVector2);
    System.out.println("Trừ vector hiện tại với một vector khác: " + arrayVector2.minus(arrayVector2));
    System.out.println("Vector hiện tại 2 " + arrayVector2);

    // Tích vô hướng
    System.out.println("Tích vô hướng của hai vector: " + arrayVector1.dot(arrayVector2));

    // Các phần tử vector được lấy mũ power.
    System.out.println("Các phần tử vector được lấy mũ power = 3: " + arrayVector1.pow(3));

    // Trích xuất tập con
    System.out.println("Trích xuất tập con: " + arrayVector1.extract(indices));
  }
}
