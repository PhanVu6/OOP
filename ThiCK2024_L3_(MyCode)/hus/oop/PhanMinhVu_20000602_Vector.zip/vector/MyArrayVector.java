package hus.oop.vector;

import java.util.ArrayList;
import java.util.Arrays;

public class MyArrayVector extends AbstractMyVector {
    private static final int DEFAULT_CAPACITY = 8;
    private double[] data;
    private int size;

    /**
     * Khởi tạo mặc định cho vector.
     */
    public MyArrayVector() {
        data = new double[DEFAULT_CAPACITY];
        size = 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public double coordinate(int index) {
        return data[index];
    }

    @Override
    public double[] coordinates() {
        return data;
    }

    @Override
    public void set(double value, int index) {
        data[index] = value;
    }

    /**
     * Cộng các phần tử của vector với value.
     * 
     * @param value
     * @return vector mới.
     */
    public MyArrayVector add(double value) {
        MyArrayVector newVector = new MyArrayVector();
        for (int i = 0; i < this.size(); i++) {
            newVector.data[i] = coordinate(i) + value;
        }
        return newVector;
    }

    /**
     * Cộng các phần tử vector hiện tại với các phần tử vector khác.
     * Nếu hai vector không cùng số chiều thì không cộng được.
     * In ra thông báo lỗi hoặc ném exception.
     * 
     * @param another
     * @return vector mới.
     */
    public MyArrayVector add(MyVector another) {
        MyArrayVector newVector = new MyArrayVector();
        double[] addNewValueVector = new double[this.size()];
        if (this.size() != another.size()) {
            throw new ArrayIndexOutOfBoundsException("Hai vector không cùng số chiều, không thể thực hiện");
        }
        for (int i = 0; i < size(); i++) {
            addNewValueVector[i] = (data[i] + another.coordinate(i));
        }

        newVector.data = addNewValueVector;
        return newVector;
    }

    /**
     * Cộng các phần tử của vector với value.
     * 
     * @param value
     * @return vector hiện tại.
     */
    public MyArrayVector addTo(double value) {
        for (int i = 0; i < this.size(); i++) {
            this.data[i] += value;
        }
        return this;
    }

    /**
     * Cộng các phần tử vector hiện tại với các phần tử vector khác.
     * Nếu hai vector không cùng số chiều thì không cộng được.
     * In ra thông báo lỗi hoặc ném exception.
     * 
     * @param another
     * @return vector hiện tại.
     */
    public MyArrayVector addTo(MyVector another) {
        double[] addNewValueVector = new double[this.size()];
        if (this.size() != another.size()) {
            throw new ArrayIndexOutOfBoundsException("Hai vector không cùng số chiều, không thể thực hiện");
        }
        for (int i = 0; i < size(); i++) {
            addNewValueVector[i] = (data[i] + another.coordinate(i));
        }

        this.data = addNewValueVector;
        return this;
    }

    /**
     * Trừ các phần tử của vector cho giá trị value.
     * 
     * @return vector mới.
     */
    public MyArrayVector minus(double value) {
        MyArrayVector newVector = new MyArrayVector();
        for (int i = 0; i < this.size(); i++) {
            newVector.data[i] = coordinate(i) - value;
        }
        return newVector;
    }

    /**
     * Trừ các phần tử của vector hiện tại cho các phần tử của vector khác.
     * Nếu hai vector không cùng số chiều thì không trừ được.
     * In ra thông báo lỗi hoặc ném exception.
     * 
     * @return vector mới.
     */
    public MyArrayVector minus(MyVector another) {
        MyArrayVector newVector = new MyArrayVector();
        double[] addNewValueVector = new double[this.size()];
        if (this.size() != another.size()) {
            throw new ArrayIndexOutOfBoundsException("Hai vector không cùng số chiều, không thể thực hiện");
        }
        for (int i = 0; i < size(); i++) {
            addNewValueVector[i] = (data[i] - another.coordinate(i));
        }

        newVector.data = addNewValueVector;
        return newVector;
    }

    /**
     * Trừ các phần tử của vector cho giá trị value.
     * 
     * @return vector hiện tại.
     */
    public MyArrayVector minusFrom(double value) {
        for (int i = 0; i < this.size(); i++) {
            this.data[i] -= value;
        }
        return this;
    }

    /**
     * Trừ các phần tử của vector hiện tại cho các phần tử của vector khác.
     * Nếu hai vector không cùng số chiều thì không trừ được.
     * In ra thông báo lỗi hoặc ném exception.
     * 
     * @return vector hiện tại.
     */
    public MyArrayVector minusFrom(MyVector another) {
        double[] addNewValueVector = new double[this.size()];
        if (this.size() != another.size()) {
            throw new ArrayIndexOutOfBoundsException("Hai vector không cùng số chiều, không thể thực hiện");
        }
        for (int i = 0; i < size(); i++) {
            addNewValueVector[i] = (data[i] - another.coordinate(i));
        }

        this.data = addNewValueVector;
        return this;
    }

    /**
     * Tích vô hướng của hai vector.
     * Hai vector chỉ có tích vô hướng nếu có cùng số chiều.
     * Nếu hai vector không cùng số chiều, in ra thông báo lỗi hoặc ném exception.
     * 
     * @return vector hiện tại.
     */
    public double dot(MyVector another) {
        if (this.size() != another.size()) {
            throw new ArrayIndexOutOfBoundsException("Hai vector không cùng số chiều, không thể thực hiện");
        }

        double result = 0;
        for (int i = 0; i < this.size(); i++)
            result += data[i] * another.coordinate(i);
        return result;
    }

    /**
     * Các phần tử của vector được lấy mũ power.
     * 
     * @param power
     * @return vector hiện tại.
     */
    public MyArrayVector pow(double power) {
        for (int i = 0; i < this.size(); i++) {
            data[i] = Math.pow(data[i], power);
        }
        return this;
    }

    /**
     * Các phần tử của vector được nhân với value.
     * 
     * @return vector hiện tại.
     */
    public MyArrayVector scale(double value) {
        for (int i = 0; i < this.size(); i++) {
            data[i] = data[i] * value;
        }
        return this;
    }

    /**
     * Lấy chuẩn của vector.
     * 
     * @return chuẩn của vector.
     */
    @Override
    public double norm() {
        /* TODO */
    }

    /**
     * Thêm một giá trị value vào tọa độ vector ở vị trí cuối cùng.
     * Nếu vector không còn đủ chỗ, mở rộng thêm kích thước vector.
     * 
     * @param value
     * @return vector hiện tại.
     */
    public MyArrayVector insert(double value) {
        enlarge();
        data[size] = value;
        size++;
        return this;
    }

    /**
     * Thêm một giá trị vào tọa độ vector ở vị trí index.
     * Nếu vector không còn đủ chỗ, mở rộng thêm kích thước vector.
     * 
     * @param value
     * @param index
     * @return vector hiện tại.
     */
    public MyArrayVector insert(double value, int index) {
        if (index >= size) {
            enlarge();
        }
        for (int i = size; i > index; i--) {
            data[i] = data[i - 1];
        }
        data[index] = value;
        size++;

        return this;
    }

    /**
     * Xóa giá trị ở tọa độ thứ index.
     * Nếu index không hợp lệ thì in ra thông báo lỗi hoặc ném exception.
     * 
     * @param index
     * @return vector hiện tại.
     */
    public MyArrayVector remove(int index) {
        if (index > size) {
            System.out.println("Index out of range");
        }
        for (int i = index; i < size - 1; i++) {
            data[i] = data[i + 1];
        }

        double[] newArr = new double[size - 2];
        System.arraycopy(data, 0, newArr, 0, data.length - 2);
        data = newArr;
        size--;
        return this;
    }

    /**
     * Trích xuất ra một vector con của vector ban đầu, có các giá trị tọa độ
     * được lấy theo các chỉ số của mảng đầu vào.
     * Ví dụ, cho vector [1 2 3 4 5], cho mảng đầu vào là {2, 1} thì vector trích
     * xuất ra
     * có tọa độ là [2 1].
     * Nếu có thỉ số trong mảng đầu vào không hợp lệ thì in ra thông báo lỗi,
     * hoặc ném exception.
     * 
     * @param indices
     * @return vector mới có tọa độ được trích xuất từ vector hiện tại.
     */
    public MyArrayVector extract(int[] indices) {
        MyArrayVector newListVector = new MyArrayVector();
        int index;
        for (int i = 0; i < indices.length; i++) {
            index = indices[i];
            if (index >= this.size() || index < 0) {
                throw new ArrayIndexOutOfBoundsException("Chỉ số không thuộc số chiều của vector");
            }
            newListVector.data[i] = data[index];
        }

        return newListVector;
    }

    /**
     * Mở rộng kích thước vector lên gấp đôi khi cần thiết.
     * 
     * @return vector hiện tại.
     */
    private MyArrayVector enlarge() {
        double[] newArr = new double[2 * data.length];
        System.arraycopy(data, 0, newArr, 0, data.length);
        data = newArr;
        return this;
    }
}
